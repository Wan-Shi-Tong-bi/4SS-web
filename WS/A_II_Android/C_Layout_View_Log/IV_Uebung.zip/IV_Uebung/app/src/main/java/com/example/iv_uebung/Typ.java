package com.example.iv_uebung;

public enum Typ {
    ARZT, PATIENT;
}
